#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<iostream>
#include<math.h>
#include<time.h>
#include"time_space_domain.h"
using namespace std;


int main()
{
	clock_t time1, time2;
	time1 = clock();
	//����˼�룬����M��N��r,���duw,du,b

	int M = 6;
	int N = 3;
	double v = 1500.0;
	double dt = 0.001;
	double dh = 10.0;
	double r = v * dt / dh;
	double* fn = linspace(M + 1);
	solve_fn(M, r, fn);
	//�ڶ���������qmn���Է����飬��duw
	//��Ч���������
	int L1 = N;
	if (N % 2 == 0)
	{
		L1 = N * N / 4;
	}
	if (N % 2 != 0)
	{
		L1 = (N * N - 1) / 4;
	}
	int L2 = N * (N - 1) / 2;
	printf("�ܷ�����ĿL2=%d\n", L2);
	printf("�ռ���ϵ������M+1=%d\n", M + 1);
	printf("��Ч���������L=%d\n", L1);
	//���䷽�������
	double** supple = area_2d(N, N);
	FILE* fp;
	fp = fopen("qmn_equation.txt", "w");
	if (fp != NULL)
	{
		for (int m = 1; m <= int(N / 2); m++)
		{
			for (int n = m; n <= N - m; n++)
			{
				for (int u = 1; u <= N - 1; u++)
				{
					for (int w = 1; w <= N - u; w++)
					{
						fprintf(fp, "%lf\n", q_coe(m, n, u, w));
					}
				}
				fprintf(fp, "%lf\n", mnfmn(m, n, fn));
			}
		}

		for (int m = 1; m <= N - 1; m++)
		{
			for (int n = 1; n <= N - m; n++)
			{
				if (m >= 1 && m <= int(N / 2) && n >= m && n <= N - m)
				{
				}
				else
				{
					supple[m - 1][n - 1] = -1.0;
					supple[n - 1][m - 1] = 1.0;
					for (int u = 1; u <= N - 1; u++)
					{
						for (int w = 1; w <= N - u; w++)
						{
							fprintf(fp, "%lf\n", supple[u - 1][w - 1]);
						}
					}
					fprintf(fp, "%lf\n", 0.0);
				}
			}
		}
		fclose(fp);
	}
	delete_2d(supple, N);
	double** qmn_equation = area_2d(L2, L2 + 1);
	double** A1 = area_2d(L2, L2);
	double* b1 = linspace(L2);
	double* x1 = linspace(L2);
	fp = fopen("qmn_equation.txt", "r");
	if (fp != NULL)
	{
		for (int i = 0; i < L2; i++)
		{
			for (int j = 0; j < L2 + 1; j++)
			{
				fscanf_s(fp, "%lf", &qmn_equation[i][j]);
			}
		}
		fclose(fp);
	}
	for (int i = 0; i < L2; i++)
	{
		for (int j = 0; j < L2; j++)
		{
			A1[i][j] = qmn_equation[i][j];
		}
		b1[i] = qmn_equation[i][L2];
	}
	LU(A1, b1, x1, L2);
	delete_2d(qmn_equation, L2);
	delete_2d(A1, L2);
	delete[]b1;
	int flag2 = 0;
	double** duw = area_2d(N, N);
	for (int m = 1; m <= N - 1; m++)
	{
		for (int n = 1; n <= N - m; n++)
		{
			duw[m - 1][n - 1] = x1[flag2];
			flag2 += 1;
		}
	}

	double* gn = linspace(M + 1);
	fn_to_gn(fn, gn, duw, M, N);
	double** Mr = area_2d(M + 1, M + 1);
	for (int n = 1; n <= M + 1; n++)
	{
		for (int u = 1; u <= M; u++)
		{
			Mr[n - 1][u - 1] = alpha(n, u);
		}
	}
	for (int n = 2; n <= M + 1; n++)
	{
		Mr[n - 1][M] = beta(M, gn, n);
	}
	double* x2 = linspace(M + 1);
	LU(Mr, gn, x2, M + 1);
	/////////////////////////////////////////////////
	double* du = linspace(M);
	double b = 0.0;
	for (int i = 0; i < M; i++)
	{
		du[i] = x2[i];
		printf("du[%d]=%lf\n", i, du[i]);
	}
	b = x2[M];
	printf("b=%lf\n", b);
	int flag = 0;
	for (int u = 1; u <= N - 1; u++)
	{
		for (int w = 1; w <= N - u; w++)
		{
			duw[u - 1][w - 1] = x1[flag];
			flag += 1;
			printf("duw[%d][%d]=%lf\n", u - 1, w - 1, duw[u - 1][w - 1]);
		}
	}
	//////////////
	double* bak = linspace(2);

	double eta = 1e-6;
	double E = 0.0;
	
	//////////////////////////////////////////////���������,��������Ͳ��ϵ��
	LS_OptimizeR_eta(eta, M, N, r, du, b, duw, bak);
	b = bak[1];
	double betamax = bak[0];
	printf("betamax=%1.12f\n", bak[0]);


	

	/////////////////////////////////////////����������������Ͳ��ϵ��
	//double betamax = 2.7380;
	//LS_OptimizeR_beta(betamax, M, N, r, du, b, duw, bak);
	//b = bak[1];
	//E = bak[0];
	//printf("betamax=%lf E=%1.12f\n", betamax, E);



	
	/////////////////////////////////////////
	delete[]bak;
	/////////////////
	fp = fopen("parameters.txt", "wb");
	if (fp != NULL)
	{
		fprintf(fp, "Paramters\n");
		fprintf(fp, "M=%d\n", M);
		fprintf(fp, "N=%d\n", N);
		fprintf(fp, "r=%lf\n", r);
		fprintf(fp, "eta=%1.9f\n", eta);
		for (int i = 0; i < M; i++)
		{
			x2[i] = du[i];
			fprintf(fp, "du[%d]=%1.9f\n", i, du[i]);
		}
		x2[M] = b;
		fprintf(fp, "b=%1.9f\n", b);
		flag = 0;
		for (int u = 1; u <= N - 1; u++)
		{
			for (int w = 1; w <= N - u; w++)
			{
				x1[flag] = duw[u - 1][w - 1];
				flag += 1;
				fprintf(fp, "duw[%d][%d]=%1.9f\n", u - 1, w - 1, duw[u - 1][w - 1]);
			}
		}
		fclose(fp);
	}

	for (int i = 0; i < M; i++)
	{
		x2[i] = du[i];
		printf("du[%d]=%lf\n", i, du[i]);
	}
	x2[M] = b;
	printf("b=%lf\n", b);
	flag = 0;
	for (int u = 1; u <= N - 1; u++)
	{
		for (int w = 1; w <= N - u; w++)
		{
			x1[flag] = duw[u - 1][w - 1];
			flag += 1;
			printf("duw[%d][%d]=%lf\n", u - 1, w - 1, duw[u - 1][w - 1]);
		}
	}
	fp = fopen("coef.txt", "w");
	if (fp != NULL)
	{
		for (int i = 0; i < M; i++)
		{
			fprintf(fp, "%1.12f\n", du[i]);
		}
		x2[M] = b;
		fprintf(fp, "%1.12f\n", b);
		flag = 0;
		for (int u = 1; u <= N - 1; u++)
		{
			for (int w = 1; w <= N - u; w++)
			{
				x1[flag] = duw[u - 1][w - 1];
				flag += 1;
				fprintf(fp, "%1.12f\n", duw[u - 1][w - 1]);
			}
		}
		fclose(fp);
	}
	///////////////////////
	fp = fopen("disp.txt", "w");
	if (fp != NULL)
	{
		//theta�����
		for (int j = 0; j < 1000; j++)
		{
			double kh = j * PI / 1000 + 1e-4;
			fprintf(fp, "%1.12f ", kh);
			for (int i = 0; i < 5; i++)//kh����
			{
				double theta = i * PI / 16;
				double delta = dispersion4(kh, theta, r, M, N, x1, x2);
				fprintf(fp, "%1.12f ", delta);
			}
			fprintf(fp, "\n");
		}
		fclose(fp);
	}
	//////////
	fp = fopen("disper.txt", "w");
	if (fp != NULL)
	{
		//theta�����
		for (int j = 0; j < 1000; j++)
		{
			double kh = j * PI / 1000 + 1e-4;
			fprintf(fp, "%1.12f ", kh);
			double delta = dispersion4(kh, 1e-12, r, M, N, x1, x2);
			fprintf(fp, "%1.12f ", delta);
			fprintf(fp, "\n");
		}
		fclose(fp);
	}
	/////////////
	fp = fopen("ErrorR.txt", "w");
	if (fp != NULL)
	{
		for (int i = 0; i < 1000; i++)
		{
			double beta = i * PI / 1000 + 1e-4;
			double delta = ErrorR(beta, M, N, r, du, b, duw);
			//fprintf(fp, "%lf %lf\n",beta, delta);
			fprintf(fp, "%1.12f %1.12f\n", beta, delta);
		}
		fclose(fp);
	}
	////////////
	double s = 0.0;
	double s1 = 0.0;
	for (int u = 1; u <= M; u++)
	{
		s1 += du[u - 1] * pow(-1.0, u + 1) / (1.0 - 4.0 * b);
	}
	double s2 = 0.0;
	for (int u = 1; u <= N - 1; u++)
	{
		for (int w = 1; w <= N - u; w++)
		{
			s2 += 2.0 * duw[u - 1][w - 1] * pow(-1.0, u + w + 1);
		}
	}
	s = 1.0 / (sqrt(2.0) * (s1 + s2));
	printf("M=%d,N=%d,r=%lf,s=%lf\n", M, N, r, s);
	////////////////
	fp = fopen("parameters.txt", "wb");
	if (fp != NULL)
	{
		fprintf(fp, "Paramters\n");
		fprintf(fp, "M=%d\n", M);
		fprintf(fp, "N=%d\n", N);
		fprintf(fp, "r=%lf\n", r);
		fprintf(fp, "eta=%1.9f\n", eta);
		for (int i = 0; i < M; i++)
		{
			x2[i] = du[i];
			fprintf(fp, "du[%d]=%1.9f\n", i, du[i]);
		}
		x2[M] = b;
		fprintf(fp, "b=%1.9f\n", b);
		flag = 0;
		for (int u = 1; u <= N - 1; u++)
		{
			for (int w = 1; w <= N - u; w++)
			{
				x1[flag] = duw[u - 1][w - 1];
				flag += 1;
				fprintf(fp, "duw[%d][%d]=%1.9f\n", u - 1, w - 1, duw[u - 1][w - 1]);
			}
		}
		fclose(fp);
	}

	///////////
	delete[]x1;
	delete_2d(Mr, M + 1);
	delete[]x2;
	delete_2d(duw, N);
	delete[]fn;
	delete[]gn;

	time2 = clock();
	double duration = (time2 - time1) / CLOCKS_PER_SEC;
	printf("���ݼ���ʱ��%lf��\n", duration);
	return 0;
}